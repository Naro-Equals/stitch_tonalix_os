import React, { useEffect, useState } from 'react';
import { WALLPAPERS } from '../data/tvApps';
import { WallpaperId } from '../types/launcher';

interface ScreensaverOverlayProps {
  isOpen: boolean;
  wallpaper: WallpaperId;
  onExit: () => void;
}

export const ScreensaverOverlay: React.FC<ScreensaverOverlayProps> = ({
  isOpen,
  wallpaper,
  onExit,
}) => {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    if (!isOpen) return;
    const timer = setInterval(() => setNow(new Date()), 5000);
    const handleKey = (e: KeyboardEvent) => {
      e.preventDefault();
      onExit();
    };
    window.addEventListener('keydown', handleKey);
    return () => {
      clearInterval(timer);
      window.removeEventListener('keydown', handleKey);
    };
  }, [isOpen, onExit]);

  if (!isOpen) return null;

  const wp = WALLPAPERS[wallpaper] ?? WALLPAPERS.obsidian;
  const timeStr = now.toLocaleTimeString('es-ES', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
  const dateStr = now.toLocaleDateString('es-ES', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  });

  return (
    <div
      role="button"
      tabIndex={0}
      aria-label="Salir del protector de pantalla"
      onClick={onExit}
      className="fixed inset-0 z-50 flex flex-col justify-end bg-[#040507] p-10 md:p-16 cursor-pointer"
    >
      {wp.imageUrl && (
        <img
          src={wp.imageUrl}
          alt=""
          referrerPolicy="no-referrer"
          className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-55"
        />
      )}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent" />

      <div className="relative z-10 flex items-end justify-between gap-6">
        <div>
          <div className="font-mono-tabular text-6xl sm:text-8xl font-medium tracking-tight text-white">
            {timeStr}
          </div>
          <p className="mt-2 text-base sm:text-lg capitalize text-white/70">{dateStr}</p>
        </div>
        <p className="text-xs text-white/45">Pulsa cualquier tecla o haz clic para volver</p>
      </div>
    </div>
  );
};
